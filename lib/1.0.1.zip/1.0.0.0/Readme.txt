neron neron1 = new neron(the importance of neurons W double[] Wis,amount of neons int);
bool w = neron1.setdata(value of neons double[]);
bool w = neron1.setdataref(value of neons double[]);
double w = neron1.setdatasum(value of neons double[]);
double w = neron1.setdatasumref(value of neons double[]);